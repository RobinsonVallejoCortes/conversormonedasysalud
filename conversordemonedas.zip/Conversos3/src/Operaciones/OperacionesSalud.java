package Operaciones;

public class OperacionesSalud {

	private static double peso;
	private static double altura;
	private static double latidos;
	
	
	public static double getPeso() {
		return peso;
	}
	public static void setPeso(double peso) {
		OperacionesSalud.peso = peso;
	}
	public static double getAltura() {
		return altura;
	}
	public static void setAltura(double altura) {
		OperacionesSalud.altura = altura;
	}
	public static double getLatidos() {
		return latidos;
	}
	public static void setLatidos(double latidos) {
		OperacionesSalud.latidos = latidos;
	}
	
	
}
