package Operaciones;

import javax.swing.JOptionPane;

public class OperacionesMatematicas{

	
	private static double Dolar;
	private static double PesoCol;
	private static double Euro;
	private static double Libras;
	private static double Yen;
	private static double Won;
	private static double EuroaPeso;
	private static double LibraaPeso;
	
	
	public static double getDolar() {
		return Dolar;
	}

	public static void setDolar(double dolar) {
		Dolar = dolar;
	}

	public static double getPesoCol() {
		return PesoCol;
	}

	public static void setPesoCol(double pesoCol) {
		PesoCol = pesoCol;
	}

	public static double getEuro() {
		return Euro;
	}

	public static void setEuro(double euro) {
		Euro = euro;
	}

	public  static double getLibras() {
		return Libras;
	}

	public static void setLibras(double libras) {
		Libras = libras;
	}

	public static double getWon() {
		return Won;
	}

	public static void setWon(double won) {
		Won = won;
	}

	public static double getYen() {
		return Yen;
	}

	public static void setYen(double yen) {
		Yen = yen;
	}

	public static double getEuroaPeso() {
		return EuroaPeso;
	}

	public static void setEuroaPeso(double euroaPeso) {
		EuroaPeso = euroaPeso;
	}

	public static double getLibraaPeso() {
		return LibraaPeso;
	}

	public static void setLibraaPeso(double libraaPeso) {
		LibraaPeso = libraaPeso;
	}	
	
	public static void ventanafinal() {
	int codigofin = JOptionPane.showConfirmDialog(null, "¿Desea Continuar?", "OK", JOptionPane.NO_OPTION, JOptionPane.CANCEL_OPTION);
	if(codigofin == JOptionPane.NO_OPTION){
		JOptionPane.showMessageDialog(null, "Programa finalizado");
    }else if(codigofin == JOptionPane.CANCEL_OPTION){
    	JOptionPane.showMessageDialog(null, "Programa finalizado");}
	}
	
	
	
	
	
}