package gui;

import java.awt.Event;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.border.EmptyBorder;

import Operaciones.OperacionesMatematicas;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class Monedas extends JFrame{

	OperacionesMatematicas misOperaciones;
	
		
	private JPanel panelSegundario;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Monedas frame = new Monedas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Monedas() {
		setForeground(new Color(128, 255, 128));
		
		OperacionesMatematicas.setDolar(0.00021);
		OperacionesMatematicas.setPesoCol(4677);
		OperacionesMatematicas.setEuro(0.00020);
		OperacionesMatematicas.setLibras(0.00017);
		OperacionesMatematicas.setYen(0.029);
		OperacionesMatematicas.setWon(0.27);
		OperacionesMatematicas.setEuroaPeso(5059.82);
		OperacionesMatematicas.setLibraaPeso(5746.14);
		
		
		setTitle("Monedas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		panelSegundario = new JPanel();
		panelSegundario.setBackground(SystemColor.info);
		panelSegundario.setForeground(SystemColor.window);
		panelSegundario.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(panelSegundario);
		panelSegundario.setLayout(null);
		
		JMenuBar menu1 = new JMenuBar();
		menu1.setBounds(10, 10, 301, 22);
		panelSegundario.add(menu1);
		
		JMenu menu2 = new JMenu("Elija la moneda a la que deseas convertir tu dinero ");
		menu1.add(menu2);
		
		JMenuItem menuitem1 = new JMenuItem("De Pesos a Dolares");
		menuitem1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
			}
		});
		menu2.add(menuitem1);
		menuitem1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
						
								
					try {
						double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de pesos colombianos a convertir a dolares"));
						double convertir = insertar * OperacionesMatematicas.getDolar();
						
						JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " Dolares");
						OperacionesMatematicas.ventanafinal();
						
					}catch(NumberFormatException b) {
						JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
					}
								
				}
		});
		
		JMenuItem menuitem2 = new JMenuItem("De Pesos a Euros");
		menu2.add(menuitem2);
		
		menuitem2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de pesos colombianos a convertir a Euros"));
					double convertir = insertar * OperacionesMatematicas.getEuro();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " Euros");
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
	
		
		
		JMenuItem menuitem3 = new JMenuItem("De Pesos a Libras");
		menu2.add(menuitem3);
		

		menuitem3.addActionListener(new ActionListener() {
			
	public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de pesos colombianos a convertir a Libras"));
					double convertir = insertar * OperacionesMatematicas.getLibras();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " Libras");
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
		
		JMenuItem menuitem4 = new JMenuItem("De Pesos a Yen");
		menu2.add(menuitem4);

		menuitem4.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de pesos colombianos a convertir a Yen"));
					double convertir = insertar * OperacionesMatematicas.getYen();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " Yen");	
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
		
		JMenuItem menuitem5 = new JMenuItem("De Pesos a Won Coreano");
		menu2.add(menuitem5);

		menuitem5.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de pesos colombianos a convertir a Won"));
					double convertir = insertar * OperacionesMatematicas.getWon();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " Won");
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
		
		JMenuItem menuitem6 = new JMenuItem("De Dolares a Pesos");
		menu2.add(menuitem6);
		menuitem6.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de dollares norteamericanos a convertir a pesos colombianos"));
					double convertir = insertar * OperacionesMatematicas.getPesoCol();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + "PesoCol");
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
		
		JMenuItem menuitem7 = new JMenuItem("De Euros a Pesos");
		menu2.add(menuitem7);
		menuitem7.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de euros a convertir a pesos colombianos"));
					double convertir = insertar * OperacionesMatematicas.getEuroaPeso();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " PesoCol");
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
		
		JMenuItem menuitem8 = new JMenuItem("De Libras a Pesos");
		menu2.add(menuitem8);
		menuitem8.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				
				
				try {
					double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de libras a convertir a pesos colombianos"));
					double convertir = insertar * OperacionesMatematicas.getLibraaPeso();	
					JOptionPane.showMessageDialog(null, "Tienes $ " + convertir + " PesoCol");
					OperacionesMatematicas.ventanafinal();
				}catch(NumberFormatException b) {
					JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
				}
							
			}
	});
		
		JMenuItem menuitem9 = new JMenuItem("Regresar");
		menu2.add(menuitem9);
		menuitem9.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				VentanaOperaciones vo = new VentanaOperaciones();
				vo.show();//esto permite enlazar este item con el segundo menu
								
							
			}
	});
		
	}
	}
