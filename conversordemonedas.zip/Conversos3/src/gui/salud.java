package gui;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Operaciones.OperacionesMatematicas;
import Operaciones.OperacionesSalud;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.SystemColor;

public class salud extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					salud frame = new salud();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public salud() {
		setTitle("Salud");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu Menu3 = new JMenu("Seleccione una opción");
		menuBar.add(Menu3);
		
		JMenuItem MenuItem1 = new JMenuItem("IMC");
		Menu3.add(MenuItem1);
		MenuItem1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
														
					try {
						double insertar = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su peso"));
						OperacionesSalud.setPeso(insertar);
						double insertar2 = Double.parseDouble(JOptionPane.showInputDialog("Ingrese su estatura en metros, ej: 1.75"));
						OperacionesSalud.setAltura(insertar2);
						double convertir = insertar / Math.pow(insertar2, 2);
						if(convertir<18.5) {
							JOptionPane.showMessageDialog(null, "Tiene bajo peso: " + convertir );	
						}else if (convertir >18.5 && convertir < 24.9 ) {
							JOptionPane.showMessageDialog(null, "Tiene peso normal: " + convertir );
						}else if (convertir >25 && convertir < 29.9 ) {
							JOptionPane.showMessageDialog(null, "Tiene sobre peso: " + convertir );
						}else if(convertir >30 ) {
							JOptionPane.showMessageDialog(null, "Tiene obesidad: " + convertir );
						}
						OperacionesMatematicas.ventanafinal();
					}catch(NumberFormatException b) {
						JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
					}
								
				}
		});
					
		JMenuItem MenuItem2 = new JMenuItem("Presión arterial");
		Menu3.add(MenuItem2);
		
		MenuItem2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
														
					try {
						double insertar3 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de latidos contados en 30 segundos"));
						OperacionesSalud.setLatidos(insertar3);
						double convertir = insertar3 * 2;
						if(convertir < 120) {
						JOptionPane.showMessageDialog(null, "Su presión arterial es: " + convertir );
						}else
							JOptionPane.showMessageDialog(null, "Consulte a su médico, su presión arterial es: " + convertir );
						OperacionesMatematicas.ventanafinal();				
					}catch(NumberFormatException b) {
						JOptionPane.showMessageDialog(null, "Por favor introduzca solo numeros");
					}
								
				}
		});
		
		JMenuItem MenuItem3 = new JMenuItem("Regresar");
		Menu3.add(MenuItem3);
		MenuItem3.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
			VentanaOperaciones vo = new VentanaOperaciones();
			vo.show();//esto permite enlazar este item con el segundo menu
							
						
		}
});
		
		
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
	}
}
