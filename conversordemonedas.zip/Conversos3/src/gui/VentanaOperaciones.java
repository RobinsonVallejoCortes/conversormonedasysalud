package gui;

import java.awt.EventQueue;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.security.PublicKey;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.AbstractDocument.Content;

import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.SystemColor;
import java.awt.Color;

public class VentanaOperaciones extends JFrame implements ActionListener{

	private JPanel panelprincipal;
	private JMenu menu1;
	private JMenuItem item1, item2;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaOperaciones frame = new VentanaOperaciones();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaOperaciones() {
		setTitle("Pantalla principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menu1 = new JMenu("Seleccione una opción");
		menuBar.add(menu1);
		
		JMenuItem item1 = new JMenuItem("Conversor de moneda");
		menu1.add(item1);
		item1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			
				Monedas ms = new Monedas();
				ms.show();//esto permite enlazar este item con el segundo menu
				
			}
		});
		
								
		JMenuItem item2 = new JMenuItem("Salud");
		menu1.add(item2);
		item2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			
				salud sl = new salud();
				sl.show();//esto permite enlazar este item con el segundo menu
				
			}
		});
		
		panelprincipal = new JPanel();
		panelprincipal.setBackground(SystemColor.activeCaption);
		panelprincipal.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(panelprincipal);
		panelprincipal.setLayout(null);
		
		item1.addActionListener(this);
		item2.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	}
	
